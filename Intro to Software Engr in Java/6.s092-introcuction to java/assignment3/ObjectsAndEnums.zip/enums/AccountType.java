package enums;

public enum AccountType {
	Personal, Business;
}
